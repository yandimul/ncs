package com.dedykuncoro.kuncorocrud.util;

/**
 * Created by Kuncoro on 26/03/2016.
 */
public class Server {
    /* 10.0.2.2 adalah IP Address localhost EMULATOR ANDROID STUDIO,
    Ganti IP Address tersebut dengan IP Laptop Apabila di RUN di HP. HP dan Laptop harus 1 jaringan */
    public static final String URL = "http://10.0.2.2/android/kuncoro_crud/";
}

