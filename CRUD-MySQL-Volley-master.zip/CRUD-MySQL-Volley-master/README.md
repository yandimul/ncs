# CRUD-MySQL-Volley

## Tutorial ##
https://dedykuncoro.com/2016/03/membuat-aplikasi-android-crud-menggunakan-database-mysql.html

## Demo App ##
https://youtu.be/taoZe8zXgfQ

## Settings Database ##
* Import kuncoro_crud.sql to your database
* Copy the android folder to your local web server (XAMPP or etc) or hosting.
* Open the koneksi.php file and customize its configuration with your webserver.
* Import CRUD-MySQL-Volley to Android Studio